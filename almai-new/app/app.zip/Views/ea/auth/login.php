<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'EA Login - Almai') ?></title>
    <link rel="stylesheet" href="<?= base_url('css/tailwind.min.css') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        html,
        body {
            background-color: #050505;
            color: #ffffff;
        }

        .bg-grid {
            background-size: 40px 40px;
            background-image: linear-gradient(to right, rgba(255, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
        }
    </style>
</head>

<body class="antialiased min-h-screen relative">
    <div class="absolute inset-0 bg-grid z-0"></div>
    <!-- Ubah warna blur menjadi hijau/emerald khas EA CEO jika diinginkan, atau pertahankan accent -->
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[400px] bg-emerald-500/20 blur-[150px] rounded-full"></div>

    <div class="relative z-10 min-h-screen flex items-center justify-center px-4 py-12">
        <div class="w-full max-w-md">
            <!-- Logo & Title -->
            <div class="text-center mb-8">
                <a href="<?= base_url('/') ?>" class="inline-flex items-center gap-2 mb-4">
                    <img src="https://almai.id/images/alma.gif" alt="ALMAI" class="h-12">
                    <span class="text-2xl font-bold">ALMAI</span>
                </a>
            </div>

            <!-- Flash Messages -->
            <?php if (session()->getFlashdata('success')): ?>
                <div class="bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 px-4 py-3 rounded-xl mb-4 text-sm">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="bg-red-500/20 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl mb-4 text-sm">
                    <?= session()->getFlashdata('error') ?>
                </div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('errors')): ?>
                <div class="bg-red-500/20 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl mb-4 text-sm">
                    <ul class="list-disc pl-4 space-y-1">
                        <?php foreach (session()->getFlashdata('errors') as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Login Card -->
            <div class="bg-[#111] border border-white/10 rounded-2xl p-8 shadow-2xl relative">
                <div class="absolute top-0 right-0 p-6 opacity-10">
                    <i class="fas fa-crown text-6xl text-emerald-500"></i>
                </div>
                
                <h2 class="text-2xl font-bold mb-2">EA Login</h2>
                <p class="text-gray-500 text-sm mb-6">Akses eksklusif untuk Executive Assistant & CEO</p>

                <form action="<?= base_url('ea/login') ?>" method="post" class="space-y-4">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Email Address</label>
                        <div class="relative">
                            <input type="email" name="email" required value="<?= old('email') ?>"
                                class="w-full bg-black border border-white/20 rounded-xl px-4 py-3 pl-12 focus:border-emerald-500 focus:outline-none transition-colors"
                                placeholder="Masukan Email">
                            <i class="fas fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Password</label>
                        <div class="relative">
                            <input type="password" name="password" id="adminPassword" required
                                class="w-full bg-black border border-white/20 rounded-xl px-4 py-3 pl-12 focus:border-emerald-500 focus:outline-none transition-colors"
                                placeholder="Masukan Password">
                            <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
                            <button type="button" onclick="togglePassword('adminPassword')" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="flex items-center justify-between text-sm">
                        <label class="flex items-center gap-2 text-gray-400 cursor-pointer hover:text-white transition-colors">
                            <input type="checkbox" name="remember" class="accent-emerald-500"> Ingat saya
                        </label>
                    </div>

                    <button type="submit" class="w-full py-4 mt-2 text-black font-bold rounded-xl transition shadow-[0_0_30px_rgba(51,232,24,0.3)]" style="background-color: #33e818;" onmouseover="this.style.backgroundColor='#2ebd15'" onmouseout="this.style.backgroundColor='#33e818'">
                        <i class="fas fa-sign-in-alt mr-2"></i> Login
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const icon = input.nextElementSibling.nextElementSibling.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
