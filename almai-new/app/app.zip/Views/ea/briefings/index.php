<?= $this->extend('ea/layouts/main') ?>

<?= $this->section('content') ?>

<div class="w-full flex flex-col gap-6">
    
    <!-- Hero / Greeting -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/10 pb-6">
        <div>
            <h1 class="text-3xl font-bold text-white mb-1"><?= esc($greeting) ?></h1>
            <p class="text-gray-400 text-sm"><i class="far fa-calendar-alt mr-2 text-[#33e818]"></i><?= esc($briefing_date) ?></p>
        </div>
        <div class="flex gap-3">
            <button class="bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-lg text-sm transition">
                <i class="fas fa-download mr-2"></i> Download PDF
            </button>
            <button class="bg-[#33e818]/10 hover:bg-[#33e818]/20 text-[#33e818] border border-[#33e818]/30 px-4 py-2 rounded-lg text-sm font-semibold transition">
                <i class="fas fa-play-circle mr-2"></i> Start Audio Briefing
            </button>
        </div>
    </div>

    <!-- AI Executive Summary -->
    <div class="bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-blue-500/20 rounded-2xl p-6 relative overflow-hidden">
        <div class="absolute top-0 right-0 p-6 opacity-20 pointer-events-none">
            <i class="fas fa-robot text-6xl text-blue-400"></i>
        </div>
        <div class="flex items-center gap-3 mb-3">
            <div class="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                <i class="fas fa-magic text-blue-400 text-sm"></i>
            </div>
            <h2 class="text-lg font-bold text-white">AI Executive Summary</h2>
        </div>
        <p class="text-gray-300 leading-relaxed max-w-4xl text-sm italic">
            "<?= esc($ai_summary) ?>"
        </p>
    </div>

    <!-- Pulse & System Status (Superadmin Style) -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <?php foreach($company_pulse as $pulse): ?>
            <?php 
                $icon = 'fas fa-chart-line';
                $iconColorClass = 'text-gray-400';
                $bgClass = 'bg-gray-500/20';
                
                if ($pulse['color'] == 'emerald') {
                    $iconColorClass = 'text-[#33e818]';
                    $bgClass = 'bg-[#33e818]/20';
                    $icon = 'fas fa-users';
                }
                elseif ($pulse['color'] == 'blue') {
                    $iconColorClass = 'text-blue-500';
                    $bgClass = 'bg-blue-500/20';
                    $icon = 'fas fa-server';
                }
                elseif ($pulse['color'] == 'purple') {
                    $iconColorClass = 'text-purple-500';
                    $bgClass = 'bg-purple-500/20';
                    $icon = 'fas fa-ticket-alt';
                }
            ?>
            <div class="bg-[#111] border border-white/10 rounded-xl md:rounded-2xl p-4 md:p-6">
                <div class="flex items-center justify-between mb-2 md:mb-4">
                    <div class="w-10 h-10 md:w-12 md:h-12 <?= $bgClass ?> rounded-lg md:rounded-xl flex items-center justify-center">
                        <i class="<?= $icon ?> <?= $iconColorClass ?> text-lg md:text-xl"></i>
                    </div>
                    <?php if($pulse['trend'] == 'up'): ?>
                        <i class="fas fa-arrow-up text-[#33e818] text-sm"></i>
                    <?php elseif($pulse['trend'] == 'down'): ?>
                        <i class="fas fa-arrow-down text-red-500 text-sm"></i>
                    <?php else: ?>
                        <i class="fas fa-minus text-gray-500 text-sm"></i>
                    <?php endif; ?>
                </div>
                <h3 class="text-xl md:text-3xl font-bold truncate text-white"><?= esc($pulse['value']) ?></h3>
                <p class="text-gray-500 text-xs md:text-sm mt-1"><?= esc($pulse['metric']) ?></p>
            </div>
        <?php endforeach; ?>

        <!-- System Status -->
        <div class="bg-[#111] border border-white/10 rounded-xl md:rounded-2xl p-4 md:p-6">
            <div class="flex items-center justify-between mb-2 md:mb-4">
                <div class="w-10 h-10 md:w-12 md:h-12 bg-[#33e818]/20 rounded-lg md:rounded-xl flex items-center justify-center">
                    <i class="fas fa-shield-alt text-[#33e818] text-lg md:text-xl"></i>
                </div>
                <span class="flex h-3 w-3 relative">
                  <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#33e818] opacity-75"></span>
                  <span class="relative inline-flex rounded-full h-3 w-3 bg-[#33e818]"></span>
                </span>
            </div>
            <h3 class="text-xl md:text-3xl font-bold truncate text-white"><?= esc($system_status['status']) ?></h3>
            <p class="text-gray-500 text-xs md:text-sm mt-1">Uptime: <?= esc($system_status['uptime']) ?></p>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Today's Schedule -->
        <div class="bg-[#1a1a1a] border border-white/5 rounded-2xl p-6">
            <div class="flex justify-between items-center mb-5">
                <h3 class="text-white font-bold text-lg"><i class="fas fa-calendar-day text-[#33e818] mr-2"></i>Today's Meetings</h3>
                <a href="<?= base_url('ea/calenders') ?>" class="text-xs text-blue-400 hover:text-blue-300">View All</a>
            </div>
            
            <?php if(empty($meetings)): ?>
                <p class="text-gray-500 text-sm italic text-center py-4">No meetings scheduled for today.</p>
            <?php else: ?>
                <div class="flex flex-col gap-4">
                    <?php foreach($meetings as $m): ?>
                        <div class="flex gap-4 items-start p-3 rounded-xl hover:bg-white/5 border border-transparent hover:border-white/5 transition">
                            <div class="min-w-[60px] text-center">
                                <p class="text-sm font-bold text-white"><?= explode(' - ', $m['time'])[0] ?></p>
                                <p class="text-xs text-gray-500"><?= explode(' - ', $m['time'])[1] ?></p>
                            </div>
                            <div class="flex-1">
                                <h4 class="text-sm font-bold text-white mb-1"><?= esc($m['title']) ?></h4>
                                <div class="flex items-center gap-3">
                                    <span class="text-xs text-gray-400"><i class="fas fa-map-marker-alt text-gray-500 mr-1"></i><?= esc($m['location'] ?? '-') ?></span>
                                    <span class="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-400 font-semibold">Meeting</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pending Tasks -->
        <div class="bg-[#1a1a1a] border border-white/5 rounded-2xl p-6">
            <div class="flex justify-between items-center mb-5">
                <h3 class="text-white font-bold text-lg"><i class="fas fa-tasks text-purple-400 mr-2"></i>Priority Tasks</h3>
                <a href="<?= base_url('ea/tasks') ?>" class="text-xs text-blue-400 hover:text-blue-300">View All</a>
            </div>
            
            <?php if(empty($tasks)): ?>
                <p class="text-gray-500 text-sm italic text-center py-4">No pending tasks.</p>
            <?php else: ?>
                <div class="flex flex-col gap-3">
                    <?php foreach($tasks as $t): ?>
                        <div class="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                            <div class="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-check text-purple-400 text-xs"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h4 class="text-sm font-semibold text-white truncate"><?= esc($t['title']) ?></h4>
                                <p class="text-xs text-gray-400 mt-0.5"><i class="far fa-clock mr-1"></i>Due: <?= esc($t['deadline']) ?></p>
                            </div>
                            <button class="text-xs bg-white/5 hover:bg-[#33e818]/20 hover:text-[#33e818] text-gray-400 px-3 py-1.5 rounded transition">
                                Done
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Waiting Approvals -->
        <div class="bg-[#1a1a1a] border border-white/5 rounded-2xl p-6">
            <div class="flex justify-between items-center mb-5">
                <h3 class="text-white font-bold text-lg"><i class="fas fa-file-signature text-yellow-400 mr-2"></i>Approvals Needed</h3>
                <a href="<?= base_url('ea/approvals') ?>" class="text-xs text-blue-400 hover:text-blue-300">View All</a>
            </div>
            
            <?php if(empty($approvals)): ?>
                <p class="text-gray-500 text-sm italic text-center py-4">No approvals waiting.</p>
            <?php else: ?>
                <div class="flex flex-col gap-3">
                    <?php foreach($approvals as $a): ?>
                        <div class="flex items-center justify-between p-3 rounded-xl hover:bg-white/5 border border-transparent hover:border-white/5 transition">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                                    <i class="fas fa-file-invoice-dollar text-yellow-500"></i>
                                </div>
                                <div>
                                    <h4 class="text-sm font-bold text-white"><?= esc($a['module']) ?></h4>
                                    <p class="text-xs text-gray-400 mt-0.5"><?= esc($a['description'] ?? 'Review Required') ?></p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-bold text-[#33e818]"><?= esc($a['amount']) ?></p>
                                <div class="flex gap-2 mt-1">
                                    <button class="text-xs text-red-400 hover:text-red-300"><i class="fas fa-times"></i></button>
                                    <button class="text-xs text-[#33e818] hover:text-[#2ebd15]"><i class="fas fa-check"></i></button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Active Reminders -->
        <div class="bg-[#1a1a1a] border border-white/5 rounded-2xl p-6">
            <div class="flex justify-between items-center mb-5">
                <h3 class="text-white font-bold text-lg"><i class="fas fa-bell text-red-400 mr-2"></i>Active Reminders</h3>
                <a href="<?= base_url('ea/reminders') ?>" class="text-xs text-blue-400 hover:text-blue-300">View All</a>
            </div>
            
            <?php if(empty($reminders)): ?>
                <p class="text-gray-500 text-sm italic text-center py-4">No active reminders.</p>
            <?php else: ?>
                <div class="flex flex-col gap-3">
                    <?php foreach($reminders as $r): ?>
                        <div class="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 border-l-2 border-l-red-500">
                            <div class="flex-1">
                                <h4 class="text-sm font-semibold text-white"><?= esc($r['title']) ?></h4>
                                <p class="text-xs text-gray-400 mt-0.5"><i class="far fa-clock mr-1"></i><?= esc($r['time']) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<?= $this->endSection() ?>
