<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!-- Hero -->
<section class="relative pt-32 pb-8 overflow-hidden">
    <div class="absolute inset-0 bg-grid z-0 pointer-events-none"></div>
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-accent/20 blur-[120px] rounded-full pointer-events-none"></div>
    <div class="container mx-auto px-6 relative z-10 text-center">
        <p class="text-accent font-bold tracking-widest text-sm mb-4 uppercase">Mentor Bersertifikat</p>
        <h1 class="text-4xl md:text-5xl font-bold mb-4 tracking-tighter">Wakil Penasihat Berjangka <span class="text-accent">WPA</span></h1>
<blockquote 
    class="text-[11px] sm:text-xs md:text-sm lg:text-base 
           text-gray-400 
           max-w-3xl sm:max-w-5xl lg:max-w-6xl mx-auto
           leading-tight lg:leading-snug px-4 py-3 
           border-l-2 border-green-500 text-left"
>
    <span class="text-white italic">
Penasihat Perdagangan Berjangka yang selanjutnya disebut Penasihat Berjangka adalah
orang perseorangan atau Badan Usaha yang memberikan Nasihat kepada pihak lain mengenai
jual beli Komoditi berdasarkan Kontrak Berjangka, Kontrak Derivatif Syariah, dan/atau
Kontrak Derivatif lainnya dengan menerima imbalan. <br><br>

Wakil Penasihat Berjangka adalah orang perseorangan yang berdasarkan kesepakatan
dengan Penasihat Berjangka, melaksanakan sebagian fungsi Penasihat Berjangka.
    </span>
</blockquote>
</section>

<!-- Action Buttons -->
<section class="py-6">
    <div class="container mx-auto px-6 text-center">
        <div class="flex flex-wrap sm:flex-nowrap gap-4 justify-center">
            <a href="<?= base_url('daftar-wpa') ?>" class="w-full sm:w-auto px-8 py-3 bg-accent text-black font-bold rounded-full hover:bg-white transition shadow-[0_0_15px_rgba(51,232,24,0.3)]">
                Daftar Menjadi WPA
            </a>
            <a href="<?= base_url('cwpa') ?>" class="w-full sm:w-auto px-8 py-3 border border-accent text-accent font-bold rounded-full hover:bg-accent/10 transition">
                Lihat CWPA
            </a>
        </div>
    </div>
</section>




<!-- WPA Grid -->
<section class="py-12">
    <div class="container mx-auto px-6">
        <?php if (empty($wpaList)): ?>
            <div class="text-center py-12 text-gray-400">
                <i class="fas fa-search text-4xl mb-4"></i>
                <p>Tidak ada WPA yang ditemukan.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
                <?php foreach ($wpaList as $wpa): ?>
                    <?= view('partials/cards/wpa_card', ['wpa' => $wpa]) ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?= $this->endSection() ?>
