<!-- Sidebar Overlay -->
<div id="sidebarOverlay" class="fixed inset-0 bg-black/50 z-40 hidden md:hidden" onclick="toggleSidebar()"></div>

<?php
$currentLevelId = session()->get('level_id');
$isAdmin = $currentLevelId == \App\Models\LevelModel::LEVEL_ADMIN; // Level 5
$isSuperAdmin = $currentLevelId == \App\Models\LevelModel::LEVEL_SUPER_ADMIN; // Level 7
$isAccounting = $currentLevelId == \App\Models\LevelModel::LEVEL_ACCOUNTING; // Level 6
?>

<!-- Sidebar -->
<aside id="sidebar" class="w-64 bg-[#0a0a0a] border-r border-white/10 fixed h-full z-50 -translate-x-full md:translate-x-0 transition-transform top-0 left-0 flex flex-col">
    <div class="p-6 border-b border-white/10 flex-shrink-0">
        <a href="<?= base_url('/') ?>" class="flex items-center gap-2">
            <img src="https://almai.id/images/alma.gif" alt="ALMAI" class="h-8">
            <span class="font-bold text-lg">ALMAI</span>
        </a>
        <p class="text-xs text-gray-500 mt-1">
            <?php if ($isSuperAdmin): ?>Super Admin Dashboard
            <?php elseif ($isAccounting): ?>Accounting Dashboard
            <?php else: ?>Admin Dashboard<?php endif; ?>
        </p>
    </div>
    <nav class="p-4 flex-1 overflow-y-auto">
        <div class="space-y-6">
            <!-- Main Menu -->
            <div>
                <p class="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Menu Utama</p>
                <ul class="space-y-1">
                    <li><a href="<?= base_url('superadmin/dashboard') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'dashboard' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-chart-pie w-4 text-center"></i> Dashboard</a></li>
                    <li><a href="<?= base_url('superadmin/users') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'users' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-users w-4 text-center"></i> Kelola User</a></li>
                    <li><a href="<?= base_url('superadmin/bot-users') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'bot_users' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-robot w-4 text-center text-accent"></i> RWA BOT</a></li>
                    <li><a href="<?= base_url('superadmin/advokasi') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'advokasi' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-shield-halved w-4 text-center text-accent"></i> Kelola Advokasi</a></li>
                    <li><a href="<?= base_url('superadmin/faq') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'faq' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-question-circle w-4 text-center"></i> Kelola FAQ</a></li>
                    <li><a href="<?= base_url('superadmin/handbook') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'handbook' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-book-open w-4 text-center text-accent"></i> Handbook</a></li>
                </ul>
            </div>

            <!-- Finance & Service -->
            <div>
                <p class="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Layanan & Keuangan</p>
                <ul class="space-y-1">
                    <li><a href="<?= base_url('superadmin/layanan') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'layanan' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-concierge-bell w-4 text-center"></i> Layanan</a></li>
                    <li><a href="<?= base_url('superadmin/event-banner') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'event_banner' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-images w-4 text-center"></i> Banner Event</a></li>
                    <li><a href="<?= base_url('superadmin/absensi') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'absensi' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-qrcode w-4 text-center text-accent"></i> Absensi Kegiatan</a></li>
                    <li><a href="<?= base_url('superadmin/transaksi') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'transaksi' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-receipt w-4 text-center"></i> Transaksi</a></li>
                    <li><a href="<?= base_url('superadmin/referral') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'referral' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-share-alt w-4 text-center"></i> Referral</a></li>
                    <li><a href="<?= base_url('superadmin/merchandise') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'merchandise' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-store w-4 text-center text-blue-400"></i> Merchandise</a></li>
                    <li><a href="<?= base_url('superadmin/voucher') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'voucher' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-ticket-alt w-4 text-center text-accent"></i> Voucher</a></li>
                    <li><a href="<?= base_url('superadmin/chat-leads') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'chat_leads' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-comments w-4 text-center"></i> Chat Leads</a></li>
                </ul>
            </div>

            <!-- Almai Poin -->
            <div>
                <p class="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Almai Poin</p>
                <ul class="space-y-1">
                    <li><a href="<?= base_url('superadmin/poin') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'poin' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-coins w-4 text-center"></i> Poin</a></li>
                    <li><a href="<?= base_url('superadmin/poin-package') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'poin_package' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-tag w-4 text-center text-accent"></i> Harga Poin</a></li>
                    <li><a href="<?= base_url('superadmin/poin/share') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'poin_share' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-share-alt w-4 text-center text-yellow-500"></i> Bagi Poin</a></li>
                </ul>
            </div>

            <!-- Partnership -->
            <div>
                <p class="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Kemitraan</p>
                <ul class="space-y-1">
                    <li><a href="<?= base_url('superadmin/wpa') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'wpa' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-user-tie w-4 text-center"></i> WPA</a></li>
                    <li><a href="<?= base_url('superadmin/cwpa') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'cwpa' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-user-graduate w-4 text-center"></i> CWPA</a></li>
                    <li><a href="<?= base_url('superadmin/cwpa/verification') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'cwpa_verification' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-check-double w-4 text-center"></i> Verifikasi CWPA</a></li>
                    <li><a href="<?= base_url('superadmin/wpa-assignment') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'wpa_assignment' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-link w-4 text-center text-blue-400"></i> Penugasan WPA</a></li>
                    <li><a href="<?= base_url('superadmin/withdrawals') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'withdrawals' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-money-bill-wave w-4 text-center"></i> Withdraw</a></li>
                </ul>
            </div>

            <!-- System -->
            <div>
                <p class="px-4 text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Sistem</p>
                <ul class="space-y-1">
                    <li><a href="<?= base_url('superadmin/kyc') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'kyc' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-crown w-4 text-center text-yellow-500"></i> Verifikasi PRO</a></li>
                    <li><a href="<?= base_url('superadmin/tim') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'tim' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-users-cog w-4 text-center"></i> Kelola Tim</a></li>
                    <li><a href="<?= base_url('superadmin/legal-documents') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'legal_documents' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-file-contract w-4 text-center"></i> Dokumen Legal</a></li>
                    <li><a href="<?= base_url('superadmin/setting') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'setting' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-cog w-4 text-center"></i> Setting</a></li>
                    <li><a href="<?= base_url('superadmin/broadcast') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'broadcast' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-bullhorn w-4 text-center"></i> Broadcast</a></li>
                    <li><a href="<?= base_url('superadmin/feedback') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'feedback' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-star w-4 text-center text-yellow-400"></i> Feedback User</a></li>
            
                    <li><a href="<?= base_url('superadmin/whatsapp-gateway') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'whatsapp_gateway' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fab fa-whatsapp w-4 text-center text-[#25D366]"></i> WhatsApp Gateway</a></li>
                    <li><a href="<?= base_url('superadmin/audit-log') ?>" class="sidebar-link <?= ($activeMenu ?? '') === 'audit_log' ? 'active' : '' ?> flex items-center gap-3 px-4 py-2 text-sm rounded-lg hover:bg-white/5 transition"><i class="fas fa-history w-4 text-center text-accent"></i> Audit Log</a></li>
                </ul>
            </div>
        </div>
    </nav>

</aside>

<script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('-translate-x-full');
        document.getElementById('sidebarOverlay').classList.toggle('hidden');
    }
</script>