<?php

namespace App\Controllers\Ea;

use App\Controllers\BaseController;

class ActivityLog extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Audit Trail & Jejak Aktivitas',
            'activities' => [
                ['time' => '10:45 AM', 'user' => 'Admin Keuangan', 'action' => 'Mengubah status invoice #INV-002 menjadi LUNAS', 'module' => 'Finance'],
                ['time' => '09:30 AM', 'user' => 'Superadmin', 'action' => 'Menambahkan role pengguna baru (Partnership)', 'module' => 'System'],
                ['time' => 'Kemarin, 16:00', 'user' => 'Manajer HR', 'action' => 'Menyetujui 3 pengajuan cuti', 'module' => 'HR'],
                ['time' => 'Kemarin, 14:15', 'user' => 'Sistem Cron', 'action' => 'Auto-backup database mingguan berhasil dijalankan', 'module' => 'IT']
            ]
        ];
        
        return view('ea/activity', $data);
    }
}
