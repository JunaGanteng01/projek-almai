<?php

namespace App\Controllers\Ea;

use App\Controllers\BaseController;
use App\Models\EaNotificationModel;

class Notifications extends BaseController
{
    public function index()
    {
        $notificationModel = new EaNotificationModel();
        
        // Simulating some date differences in the view will be needed, or we just pass the objects
        $alerts = $notificationModel->where('is_archived', 0)
                                    ->orderBy('created_at', 'DESC')
                                    ->findAll();

        // Format times for the view (dummy format logic)
        foreach ($alerts as &$alert) {
            $alert['time'] = date('H:i, d M Y', strtotime($alert['created_at']));
        }

        $data = [
            'title' => 'Pusat Notifikasi & Peringatan',
            'alerts' => $alerts
        ];
        
        return view('ea/notifications', $data);
    }
}
