<?php

namespace App\Controllers\Ea;

use App\Controllers\BaseController;
use App\Models\EaMeetingModel;

class Meetings extends BaseController
{
    protected $meetingModel;

    public function __construct()
    {
        $this->meetingModel = new EaMeetingModel();
    }

    public function index()
    {
        $meetings = $this->meetingModel->orderBy('start_time', 'DESC')->findAll();
        
        $todayStart = date('Y-m-d 00:00:00');
        $todayEnd = date('Y-m-d 23:59:59');
        
        $todayMeetings = array_filter($meetings, function($m) use ($todayStart, $todayEnd) {
            return $m['start_time'] >= $todayStart && $m['start_time'] <= $todayEnd;
        });
        
        $completedToday = array_filter($todayMeetings, function($m) {
            return $m['status'] === 'Completed';
        });

        $data = [
            'title' => 'Manajemen Meeting',
            'meetings' => $meetings,
            'today_total' => count($todayMeetings),
            'today_completed' => count($completedToday),
            'today_pending' => count($todayMeetings) - count($completedToday),
        ];

        return view('ea/meetings/index', $data);
    }

    public function create()
    {
        $data = [
            'title' => 'Buat Meeting Baru'
        ];
        return view('ea/meetings/create', $data);
    }

    public function store()
    {
        $this->meetingModel->insert([
            'title'       => $this->request->getPost('title'),
            'start_time'  => $this->request->getPost('date') . ' ' . $this->request->getPost('time'),
            'end_time'    => $this->request->getPost('date') . ' ' . date('H:i:s', strtotime($this->request->getPost('time') . ' +1 hour')),
            'location'    => $this->request->getPost('link') ?: 'TBD',
            'status'      => $this->request->getPost('status')
        ]);

        return redirect()->to(base_url('ea/meetings'))->with('success', 'Meeting berhasil dijadwalkan.');
    }

    public function edit($id)
    {
        $meeting = $this->meetingModel->find($id);
        if (!$meeting) {
            return redirect()->to(base_url('ea/meetings'))->with('error', 'Meeting tidak ditemukan.');
        }

        $data = [
            'title' => 'Edit Meeting',
            'meeting' => $meeting
        ];

        return view('ea/meetings/edit', $data);
    }

    public function update($id)
    {
        $meeting = $this->meetingModel->find($id);
        if (!$meeting) {
            return redirect()->to(base_url('ea/meetings'))->with('error', 'Meeting tidak ditemukan.');
        }

        $this->meetingModel->update($id, [
            'title'       => $this->request->getPost('title'),
            'start_time'  => $this->request->getPost('date') . ' ' . $this->request->getPost('time'),
            'end_time'    => $this->request->getPost('date') . ' ' . date('H:i:s', strtotime($this->request->getPost('time') . ' +1 hour')),
            'location'    => $this->request->getPost('link') ?: 'TBD',
            'status'      => $this->request->getPost('status')
        ]);

        return redirect()->to(base_url('ea/meetings'))->with('success', 'Meeting berhasil diperbarui.');
    }

    public function delete($id)
    {
        $meeting = $this->meetingModel->find($id);
        if ($meeting) {
            $this->meetingModel->delete($id);
            return redirect()->to(base_url('ea/meetings'))->with('success', 'Meeting berhasil dihapus.');
        }
        return redirect()->to(base_url('ea/meetings'))->with('error', 'Meeting tidak ditemukan.');
    }
}
