<?php

namespace App\Controllers\Ea;

use App\Controllers\BaseController;
use App\Models\EaTaskModel;
use App\Models\EaMeetingModel;
use App\Models\EaApprovalModel;
use App\Models\EaReminderModel;

class Briefing extends BaseController
{
    public function index()
    {
        $hour = date('H');
        $greeting = 'Pagi';
        if ($hour >= 12 && $hour < 15) {
            $greeting = 'Siang';
        } elseif ($hour >= 15 && $hour < 18) {
            $greeting = 'Sore';
        } elseif ($hour >= 18) {
            $greeting = 'Malam';
        }

        $taskModel = new EaTaskModel();
        $meetingModel = new EaMeetingModel();
        $approvalModel = new EaApprovalModel();
        $reminderModel = new EaReminderModel();

        $data = [
            'title' => 'CEO Briefing',
            'greeting' => 'Selamat ' . $greeting . ', Chief!',
            'briefing_date' => date('l, d F Y'),
            
            'system_status' => [
                'status' => 'Normal',
                'uptime' => '99.9%',
                'active_users' => 1240,
                'last_incident' => 'Tidak ada dalam 24 jam terakhir.'
            ],

            'ai_summary' => "Secara umum performa perusahaan hari ini sangat positif. Pendapatan meningkat 15% dibandingkan minggu lalu, dan terdapat 4 meeting strategis yang perlu Anda hadiri. Ada 3 approval dari divisi Finance yang membutuhkan persetujuan segera sebelum pukul 15:00.",
        ];

        $meetings = $meetingModel->where('status', 'Upcoming')->orderBy('start_time', 'ASC')->findAll(5);
        foreach ($meetings as &$m) {
            $m['time'] = date('H:i', strtotime($m['start_time'])) . ' - ' . date('H:i', strtotime($m['end_time']));
        }

        $tasks = $taskModel->where('status', 'Pending')->orderBy('deadline', 'ASC')->findAll(5);
        foreach ($tasks as &$t) {
            $t['deadline'] = date('d M Y, H:i', strtotime($t['deadline']));
        }

        $approvals = $approvalModel->where('status', 'Waiting')->orderBy('created_at', 'ASC')->findAll(5);
        foreach ($approvals as &$a) {
            $a['id'] = $a['approval_code'];
            $a['amount'] = 'Rp ' . number_format($a['amount'], 0, ',', '.');
        }

        $reminders = $reminderModel->where('status', 'Active')->orderBy('reminder_time', 'ASC')->findAll(5);
        foreach ($reminders as &$r) {
            $r['time'] = date('d M Y, H:i', strtotime($r['reminder_time']));
        }

        $data['meetings'] = $meetings;
        $data['tasks'] = $tasks;
        $data['approvals'] = $approvals;
        $data['reminders'] = $reminders;

        $data['company_pulse'] = [
            ['metric' => 'New Leads', 'value' => '+38', 'trend' => 'up', 'color' => 'emerald'],
            ['metric' => 'Server Load', 'value' => '45%', 'trend' => 'stable', 'color' => 'blue'],
            ['metric' => 'Pending Tickets', 'value' => '12', 'trend' => 'down', 'color' => 'purple']
        ];
        
        // Generate Dynamic AI Summary
        $data['ai_summary'] = $this->generateAiSummary($meetings, $tasks, $approvals);
        
        return view('ea/briefings/index', $data);
    }

    private function generateAiSummary($meetings, $tasks, $approvals)
    {
        $apiKey = getenv('GEMINI_API_KEY');
        if (!$apiKey) {
            return "AI Summary tidak tersedia (API Key belum dikonfigurasi).";
        }

        $prompt = "Buatkan summary singkat eksekutif dalam bahasa Indonesia (maks 3 kalimat) untuk CEO hari ini berdasarkan data berikut:\n";
        $prompt .= "- Jumlah meeting hari ini: " . count($meetings) . "\n";
        $prompt .= "- Jumlah task tertunda: " . count($tasks) . "\n";
        $prompt .= "- Jumlah approval menunggu: " . count($approvals) . "\n";
        $prompt .= "Berikan ringkasan yang profesional dan mendorong eksekusi.";

        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $apiKey;
        $data = [
            "contents" => [
                ["parts" => [["text" => $prompt]]]
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
        // Timeout to prevent hanging
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            return "Gagal memuat AI Summary (Timeout/Error).";
        }

        $res = json_decode($response, true);
        if (isset($res['candidates'][0]['content']['parts'][0]['text'])) {
            return trim($res['candidates'][0]['content']['parts'][0]['text']);
        }

        return "Secara umum performa perusahaan hari ini sangat positif. (Fallback Summary)";
    }
}
