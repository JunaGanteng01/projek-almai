<?php

namespace App\Controllers\Ea;

use App\Controllers\BaseController;

class QuickActions extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Tindakan Strategis Cepat',
        ];
        
        return view('ea/quick_actions', $data);
    }

    public function createTask()
    {
        return view('ea/forms/create_task', ['title' => 'Buat Task Baru']);
    }

    public function storeTask()
    {
        $taskModel = new \App\Models\EaTaskModel();
        
        $data = [
            'title'       => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'due_date'    => $this->request->getPost('due_date'),
            'status'      => 'pending',
            'priority'    => $this->request->getPost('priority') ?? 'medium',
        ];

        $taskModel->insert($data);
        
        return redirect()->to('ea/briefing')->with('success', 'Task berhasil dibuat!');
    }

    public function createMeeting()
    {
        return view('ea/forms/create_meeting', ['title' => 'Jadwalkan Meeting']);
    }

    public function storeMeeting()
    {
        $meetingModel = new \App\Models\EaMeetingModel();
        
        $data = [
            'title'       => $this->request->getPost('title'),
            'date'        => $this->request->getPost('date'),
            'time'        => $this->request->getPost('time'),
            'participants'=> $this->request->getPost('participants'),
            'link'        => $this->request->getPost('link'),
        ];

        $meetingModel->insert($data);
        
        return redirect()->to('ea/briefing')->with('success', 'Meeting berhasil dijadwalkan!');
    }

    public function createReminder()
    {
        return view('ea/forms/create_reminder', ['title' => 'Buat Reminder']);
    }

    public function storeReminder()
    {
        $reminderModel = new \App\Models\EaReminderModel();
        
        $data = [
            'title'       => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'date'        => $this->request->getPost('date'),
            'time'        => $this->request->getPost('time'),
            'priority'    => $this->request->getPost('priority') ?? 'normal',
        ];

        $reminderModel->insert($data);
        
        return redirect()->to('ea/briefing')->with('success', 'Reminder berhasil dibuat!');
    }
}
