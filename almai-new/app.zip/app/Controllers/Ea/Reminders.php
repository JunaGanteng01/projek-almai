<?php

namespace App\Controllers\Ea;

use App\Controllers\BaseController;
use App\Models\EaReminderModel;

class Reminders extends BaseController
{
    protected $reminderModel;

    public function __construct()
    {
        $this->reminderModel = new EaReminderModel();
    }

    public function index()
    {
        $reminders = $this->reminderModel->orderBy('reminder_time', 'DESC')->findAll();
        
        $todayStart = date('Y-m-d 00:00:00');
        $todayEnd = date('Y-m-d 23:59:59');
        
        $todayReminders = array_filter($reminders, function($r) use ($todayStart, $todayEnd) {
            return $r['reminder_time'] >= $todayStart && $r['reminder_time'] <= $todayEnd;
        });
        
        $activeToday = array_filter($todayReminders, function($r) {
            return $r['status'] === 'Active';
        });

        $data = [
            'title' => 'Manajemen Reminder',
            'reminders' => $reminders,
            'today_total' => count($todayReminders),
            'today_active' => count($activeToday),
            'today_inactive' => count($todayReminders) - count($activeToday),
        ];

        return view('ea/reminders/index', $data);
    }

    public function edit($id)
    {
        $reminder = $this->reminderModel->find($id);
        if (!$reminder) {
            return redirect()->to(base_url('ea/reminders'))->with('error', 'Reminder tidak ditemukan.');
        }

        $data = [
            'title' => 'Edit Reminder',
            'reminder' => $reminder
        ];

        return view('ea/reminders/edit', $data);
    }

    public function update($id)
    {
        $reminder = $this->reminderModel->find($id);
        if (!$reminder) {
            return redirect()->to(base_url('ea/reminders'))->with('error', 'Reminder tidak ditemukan.');
        }

        $this->reminderModel->update($id, [
            'title'         => $this->request->getPost('title'),
            'reminder_time' => $this->request->getPost('date') . ' ' . $this->request->getPost('time'),
            'type'          => $this->request->getPost('priority'),
            'status'        => $this->request->getPost('status')
        ]);

        return redirect()->to(base_url('ea/reminders'))->with('success', 'Reminder berhasil diperbarui.');
    }

    public function delete($id)
    {
        $reminder = $this->reminderModel->find($id);
        if ($reminder) {
            $this->reminderModel->delete($id);
            return redirect()->to(base_url('ea/reminders'))->with('success', 'Reminder berhasil dihapus.');
        }
        return redirect()->to(base_url('ea/reminders'))->with('error', 'Reminder tidak ditemukan.');
    }
}
