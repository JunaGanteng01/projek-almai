<?php

namespace App\Controllers\Webhook;

use App\Controllers\BaseController;
use App\Models\OtpModel;
use App\Libraries\Balesotomatis;

class BalesotomatisWebhook extends BaseController
{
    public function incoming()
    {
        $logging = [];

        // 1. Verify Authentication Header (Device ID/Number ID)
        $webhookKey = env('BALESOTOMATIS_WEBHOOK_KEY');
        $headerId = $this->request->getHeaderLine('BLS-OTO-NUMBERID');

        // Log the header to help user figure out their Number ID
        log_message('info', 'DEBUG - Balesotomatis Number ID received is: ' . $headerId);

        // Cek keamanan hanya jika BALESOTOMATIS_WEBHOOK_KEY sudah diisi di .env
        if (!empty($webhookKey) && $headerId !== $webhookKey) {
            log_message('error', 'Balesotomatis Webhook Unauthorized: Invalid BLS-OTO-NUMBERID');
            return $this->response->setStatusCode(401)->setJSON(['success' => false, 'message' => 'Unauthorized']);
        }

        $json = $this->request->getJSON(true);

        if (!$json || !isset($json['type'])) {
            return $this->response->setStatusCode(400)->setJSON(['success' => false, 'message' => 'Invalid payload']);
        }

        if ($json['type'] === 'incoming_chat' && isset($json['data'])) {
            $data = $json['data'];

            // Extract phone number from chat_id (e.g. 62812345678@c.us)
            $chatId = $data['chat_id'] ?? '';
            $phone = explode('@', $chatId)[0];

            $messageBody = trim($data['message_body'] ?? '');

            // Only process if message body exists and it's from user
            if (!empty($messageBody) && empty($data['is_from_me'])) {
                log_message('info', 'Balesotomatis Webhook received msg: ' . $messageBody . ' from ' . $phone);

                // Check if it's the attendance checkin confirmation message
                if (stripos($messageBody, 'Saya Akan Hadir') !== false) {
                    // 1. Find user by phone number
                    $userModel = new \App\Models\UserModel();
                    $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
                    $suffix = substr($cleanPhone, -9);
                    $user = $userModel->like('phone', $suffix)->first();

                    if ($user) {
                        // 2. Find the user's latest check-in
                        $absensiPesertaModel = new \App\Models\AbsensiPesertaModel();
                        $latestCheckin = $absensiPesertaModel->where('user_id', $user['id'])
                            ->orderBy('created_at', 'DESC')
                            ->first();

                        if ($latestCheckin) {
                            $kegiatanType = $latestCheckin['kegiatan_type'];
                            $kegiatanId = $latestCheckin['kegiatan_id'];

                            // Find the event
                            $models = [
                                'seminar_fgd' => new \App\Models\SeminarModel(),
                                'pelatihan_simulasi' => new \App\Models\PelatihanModel(),
                                'signals' => new \App\Models\SignalModel(),
                                'konsultasi' => new \App\Models\KonsultasiModel(),
                                'expert_advisor' => new \App\Models\ExpertAdvisorModel(),
                                'kegiatan_lainnya' => new \App\Models\KegiatanLainnyaModel(),
                            ];

                            if (isset($models[$kegiatanType])) {
                                $event = $models[$kegiatanType]->find($kegiatanId);

                                if ($event && !empty($event['format_notif_wa'])) {
                                    $templateId = $event['format_notif_wa'];
                                    $replyMessage = '';

                                    if (is_numeric($templateId)) {
                                        $waTemplateModel = new \App\Models\WhatsappTemplateModel();
                                        $template = $waTemplateModel->find($templateId);
                                        if ($template && !empty($template['isi_pesan'])) {
                                            $replyMessage = $template['isi_pesan'];
                                        }
                                    } else {
                                        $replyMessage = $templateId;
                                    }

                                    if (!empty($replyMessage)) {
                                        $replyMessage = str_replace(['{name}', '{nama}'], $user['name'], $replyMessage);

                                        $secretKey = env('BALESOTOMATIS_SECRET_KEY');
                                        $licensesKey = env('BALESOTOMATIS_LICENSES_KEY');

                                        if ($secretKey && $licensesKey) {
                                            Balesotomatis::configure($secretKey, $licensesKey);
                                            Balesotomatis::sendPersonalMessage($phone, $replyMessage);
                                            log_message('info', 'Attendance confirmation sent via Webhook for ' . $phone);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // Extract 6-digit OTP using regex
                elseif (preg_match('/\b(\d{6})\b/', $messageBody, $matches)) {
                    $extractedOtp = $matches[1];

                    // Check OTP
                    $otpModel = new OtpModel();
                    $isVerified = $otpModel->markAsVerifiedViaWa($phone, $extractedOtp);

                    $logging = [
                        '$isVerified' => $isVerified,
                        '$phone' => $phone,
                        '$extractedOtp' => $extractedOtp,
                    ];

                    if ($isVerified) {
                        log_message('info', 'OTP ' . $extractedOtp . ' verified via Webhook for ' . $phone);
                        // Send success reply via Balesotomatis
                        $secretKey = env('BALESOTOMATIS_SECRET_KEY');
                        $licensesKey = env('BALESOTOMATIS_LICENSES_KEY');

                        if ($secretKey && $licensesKey) {
                            Balesotomatis::configure($secretKey, $licensesKey);
                            $logging['responseSendPersonalMessage'] = Balesotomatis::sendPersonalMessage($phone, "✅ Kode OTP berhasil diverifikasi.\n\nSilakan kembali ke browser Anda untuk melanjutkan pendaftaran.");
                        }
                    }
                }
            }
        }

        return $this->response->setJSON(['success' => true, '$logging' => $logging]);
    }
}
