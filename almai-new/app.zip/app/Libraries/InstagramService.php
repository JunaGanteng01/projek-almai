<?php

namespace App\Libraries;

class InstagramService
{
    private $apiKey = '1fb7098361mshe2ade6bf5ad466cp1d0fd5jsn60b4ebaa414e';
    private $apiHost = 'instagram120.p.rapidapi.com';
    
    /**
     * Get Instagram profile data
     * 
     * @param string $username Instagram username
     * @return array|null Profile data or null on error
     */
    public function getProfile($username)
    {
        if (empty($username)) {
            return null;
        }
        
        // Remove @ if present
        $username = str_replace('@', '', $username);
        $username = trim($username);
        
        // Caching logic
        $cacheKey = 'instagram_profile_' . md5($username);
        if ($cachedData = cache($cacheKey)) {
            return $cachedData;
        }
        
        $curl = curl_init();
        
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://instagram120.p.rapidapi.com/api/instagram/profile",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode([
                'username' => $username
            ]),
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",
                "x-rapidapi-host: {$this->apiHost}",
                "x-rapidapi-key: {$this->apiKey}"
            ],
        ]);
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        curl_close($curl);
        
        if ($err) {
            if (function_exists('log_message')) {
                log_message('error', 'Instagram API Error: ' . $err);
            }
            return null;
        }
        
        if ($httpCode !== 200) {
            if (function_exists('log_message')) {
                log_message('error', 'Instagram API HTTP Error: ' . $httpCode . ' Response: ' . substr($response, 0, 500));
            }
            return null;
        }
        
        $data = json_decode($response, true);
        
        if (function_exists('log_message')) {
            log_message('debug', 'Instagram API Response for ' . $username . ': ' . json_encode($data));
        }
        
        // Check if response has 'result' key
        if (!$data || !isset($data['result'])) {
            if (function_exists('log_message')) {
                log_message('error', 'Instagram API Invalid Response: ' . substr($response, 0, 500));
            }
            return null;
        }
        
        $result = $data['result'];
        
        // Save to cache for 1 week (604800 seconds)
        cache()->save($cacheKey, $result, 604800);
        
        // Return the 'result' object which contains profile info
        return $result;
    }
    
    /**
     * Get Instagram media posts
     * 
     * @param string $username Instagram username
     * @param int $limit Number of posts to return
     * @return array Media posts
     */
    public function getMedia($username, $limit = 9)
    {
        // This API doesn't return media in profile endpoint
        // Would need separate endpoint for media
        return [];
    }
    
    /**
     * Format follower count
     * 
     * @param int $count Follower count
     * @return string Formatted count (e.g., "1.2M", "10K")
     */
    public function formatFollowerCount($count)
    {
        if ($count >= 1000000) {
            return round($count / 1000000, 1) . 'M';
        } elseif ($count >= 1000) {
            return round($count / 1000, 1) . 'K';
        }
        return number_format($count);
    }
}
