<?php

namespace App\Models;

use CodeIgniter\Model;

class CsConversationModel extends Model
{
    protected $table            = 'cs_conversations';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'platform',
        'platform_user_id',
        'customer_name',
        'customer_avatar',
        'last_message',
        'last_message_at',
        'status',
        'created_at',
        'updated_at'
    ];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    /**
     * Dapatkan semua percakapan yang masih open
     */
    public function getActiveConversations()
    {
        return $this->where('status', 'open')
            ->orderBy('last_message_at', 'DESC')
            ->findAll();
    }
}
