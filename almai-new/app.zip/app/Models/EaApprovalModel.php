<?php

namespace App\Models;

use CodeIgniter\Model;

class EaApprovalModel extends Model
{
    protected $table            = 'ea_approvals';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['approval_code', 'title', 'module', 'requested_by', 'amount', 'description', 'status'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
}
